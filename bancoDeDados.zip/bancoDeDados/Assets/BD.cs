﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BD : MonoBehaviour {


    public InputField login, password;
    public Text r;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void TryLogin()
    {
        StartCoroutine(LoginAccount());
    }

    IEnumerator LoginAccount()
    {
        string resp, url = @"http://localhost/aula/";
        WWWForm Form = new WWWForm();
        Form.AddField("login", login.text);
        Form.AddField("password", password.text);

        WWW www = new WWW(url, Form);
        yield return www;

        resp = www.text;

        if (resp == "true")
        {
            r.text = "Cena login certo";
        }
        else
        {
            r.text = "Cena erro de login";
        }

        //print(www.text);
        
    }
}
