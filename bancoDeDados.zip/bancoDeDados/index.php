<?php 

	if(isset($_POST['login'])){$login = $_POST['login'];}else{$login = "";}
	if(isset($_POST['password'])){$password = $_POST['password']; }else{$password = "";}
	
	if($login == "admin" && $password == "admin"){
		echo "true";
	}else{
		echo "false";
	}

?>